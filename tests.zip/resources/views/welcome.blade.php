@extends('layout.app')

@section('page_title')
    Manage shiift and get shifts
@endsection

@section('page_content')
   
@endsection
