<?php $__env->startSection('page_title'); ?>
    Auto assign
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <div class="pt-5 pb-5">
        <div class="container">

            <?php echo $__env->make('users.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row mt-0 mt-md-4">
                <div class="col-lg-3 col-md-4 col-12">

                    <?php echo $__env->make('users.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                <div class="col-lg-9 col-md-8 col-12">



                    <div class="card-header mb-3">
                        <h3 class="mb-0">Book Shifts</h3>
                    </div>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="shadow-lg p-3 mb-2 bg-white rounded">
                            <div class="row">
                                <div class="col">
                                    <h3 class="mb-0 h3"><?php echo e($request->shift->title); ?> </h3>
                                    <span class="me-2 fs-6">
                                        <span class="text-dark  me-1 fw-semi-bold">request
                                            date</span><?php echo e(date('j M, Y', strtotime($request->created_at))); ?>

                                    </span>
                                    <span class="me-2 fs-6">
                                </div>
                                <div class="col-auto">
                                    <h4 class="text-dark  me-1 mb-0 fw-semi-bold">Location:</h4> <?php echo e($request->shift->location); ?>

                                    <span class="">up to # <?php echo e($request->shift->salary); ?> per hour
                                    </span>
                                    
                                </div>
                                <div class="col-auto ">
                                    <?php if($request->status == 'pending'): ?>
                                        <div class="badge bg-warning">
                                            <?php echo e($request->status); ?>

                                        </div>
                                    <?php elseif($request->status == 'approved'): ?>
                                        <div class="badge bg-primary">
                                            <?php echo e($request->status); ?>

                                        </div>
                                    <?php elseif($request->status == 'rejected'): ?>
                                        <div class="badge bg-danger">
                                            <?php echo e($request->status); ?>

                                        </div>
                                    <?php elseif($request->status == 'completed'): ?>
                                        <div class="badge bg-success">
                                            <?php echo e($request->status); ?>

                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        27 Mar, 2023
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shitf_manager\resources\views/users/bookshifts.blade.php ENDPATH**/ ?>