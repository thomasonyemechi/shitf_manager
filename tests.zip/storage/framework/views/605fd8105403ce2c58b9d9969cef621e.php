<div>
    

    <?php $__env->startSection('title'); ?>
        Create a new shift
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('content'); ?>
        <div class="container-fluid p-4">



            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="border-bottom pb-4 mb-4 d-md-flex align-items-center justify-content-between">
                        <div class="mb-3 mb-md-0">
                            <h1 class="mb-1 h2 fw-bold">
                                Create Shifts
                            </h1>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="/admin/">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Create Shift
                                    </li>
                                </ol>
                            </nav>
                        </div>
                        <div>
                            <button class="btn btn-outline-white" data-bs-toggle="modal"
                                data-bs-target="#createShift">Create
                                New Shift</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="card mb-4">
                        <div class="card-header border-bottom-0">
                            <form class="d-flex align-items-center">
                                <span class="position-absolute ps-3 search-icon">
                                    <i class="fe fe-search"></i>
                                </span>
                                <input type="search" class="form-control ps-6" placeholder="Search Shift" />
                            </form>
                        </div>
                        <!-- Table  -->
                        <div class="table-responsive border-0 overflow-y-hidden">
                            <table class="table mb-0 text-nowrap">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col" class="border-0">Shift</th>
                                        <th scope="col" class="border-0">Created By</th>
                                        <th scope="col" class="border-0">Needed</th>
                                        <th scope="col" class="border-0">Request</th>
                                        <th scope="col" class="border-0">Approved</th>
                                        <th scope="col" class="border-0"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="border-top-0">
                                            <a href="#" class="text-inherit">
                                                <div class="d-lg-flex align-items-center">
                                                    <div class="ms-lg-3 mt-2 mt-lg-0">
                                                        <h4 class="mb-1 text-primary-hover">
                                                            Revolutionize how you build the web...
                                                        </h4>
                                                        <span class="text-inherit">Added on 7 July, 2021</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                        <td class="align-middle border-top-0">
                                            <div class="d-flex align-items-center">
                                                <img src="../../assets/images/avatar/avatar-7.jpg" alt=""
                                                    class="rounded-circle avatar-xs me-2" />
                                                <h5 class="mb-0">Reva Yokk</h5>
                                            </div>
                                        </td>
                                        <td class="align-middle border-top-0">30</td>
                                        <td class="align-middle border-top-0">120</td>
                                        <td class="align-middle border-top-0">25</td>
                                        <td class="align-middle border-top-0">
                                            <span class="dropdown dropstart">
                                                <a class="text-decoration-none text-muted" href="#" role="button"
                                                    id="courseDropdown1" data-bs-toggle="dropdown" data-bs-offset="-20,20"
                                                    aria-expanded="false">
                                                    <i class="fe fe-more-vertical"></i>
                                                </a>
                                                <span class="dropdown-menu" aria-labelledby="courseDropdown1">
                                                    <span class="dropdown-header">Settings</span>
                                                    <a class="dropdown-item" href="#"><i
                                                            class="fe fe-layers dropdown-item-icon"></i>See More</a>
                                                    <a class="dropdown-item" href="#"><i
                                                            class="fe fe-layers dropdown-item-icon"></i>See More</a>
                                                    <a class="dropdown-item" href="#"><i
                                                            class="fe fe-trash dropdown-item-icon"></i>Delete
                                                        Shift</a>
                                                </span>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- Card Footer -->
                        <div class="card-footer border-top-0">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination justify-content-center mb-0">
                                    <li class="page-item disabled">
                                        <a class="page-link mx-1 rounded" href="#" tabindex="-1"
                                            aria-disabled="true"><i class="mdi mdi-chevron-left"></i></a>
                                    </li>
                                    <li class="page-item active">
                                        <a class="page-link mx-1 rounded" href="#">1</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link mx-1 rounded" href="#">2</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link mx-1 rounded" href="#">3</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link mx-1 rounded" href="#"><i
                                                class="mdi mdi-chevron-right"></i></a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="modal fade" id="createShift" tabindex="-1" role="dialog" aria-labelledby="newCatgoryLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title mb-0" id="newCatgoryLabel">
                            Create New Shift
                        </h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true"><i class="fe fe-x-circle"></i></span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="#" method="POST">
                            <div class="mb-3 mb-2">
                                <label class="form-label" for="title">Shifts Title<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" wire:model.lazy="title"
                                    placeholder="Write a Category" name="title" required>
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="row">
                                <div class="col-md-3">
                                    <div class="mb-3 mb-2">
                                        <label class="form-label">Salary<span class="text-danger">*</span></label>
                                        <input type="number" step="0.00" name="salary" wire:model.lazy="salary"
                                            class="form-control" placeholder="eg 30.56" required> </small>
                                        <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="mb-3 mb-2">
                                        <label class="form-label">Workers Needed</label>
                                        <input type="number" class="form-control" name="workers_needed"
                                            wire:model.lazy="workers_needed" placeholder="eg 10" required> </small>
                                        <?php $__errorArgs = ['workers_needed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3 mb-2">
                                        <label class="form-label">Location<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="location"
                                            wire:model.lazy="location" placeholder="Write a Location" required>
                                        <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3 mb-2">
                                        <label class="form-label">Job Type<span class="text-danger">*</span></label>
                                        <select class="selectpicker" name="type" wire:model.lazy="type"
                                            data-width="100%">
                                            <option selected disabled>Select</option>
                                            <option>Permanent</option>>
                                            <option>Temporary</option>>
                                        </select>
                                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3 mb-2">
                                        <label class="form-label">Discipline</label>
                                        <select class="selectpicker" name="discipline" wire:model.lazy="discipline"
                                            data-width="100%">
                                            <option selected disabled>Select</option>
                                            <option>Healthcare Assistant Jobs</option>>
                                        </select>
                                        <?php $__errorArgs = ['discipline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="mb-3 mb-2">
                                        <label class="form-label">Reference</label>
                                        <input type="text" class="form-control" name="reference"
                                            wire:model.lazy="reference" placeholder="Write a Reference" required>
                                        <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3 mb-3">
                                <label class="form-label">Job Description</label>
                                <textarea name="" class="form-control" rows="5" name="description" wire:model.lazy="description"></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </form>

                        <div>
                            <button class="btn btn-primary" wire:click="storeShift">Create</button>
                            <button type="button" class="btn btn-outline-white" data-bs-dismiss="modal">
                                Close
                            </button>
                        </div>



                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shitf_manager\resources\views/livewire/admin/create-shift-index.blade.php ENDPATH**/ ?>