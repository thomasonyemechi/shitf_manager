<div class="footer">
    <div class="container">
        <div class="row align-items-center g-0 border-top py-2">
            <div class="col-md-6 col-12 text-center text-md-start">
                <span>© 2021 <?php echo e(env('APP_NAME')); ?>. All Rights Reserved.</span>
            </div>
            <div class="col-12 col-md-6">
                <nav class="nav nav-footer justify-content-center justify-content-md-end">
                    <a class="nav-link active ps-0" href="#">Privacy</a>
                    <a class="nav-link" href="#">Terms </a>
                    <a class="nav-link" href="#">Feedback</a>
                    <a class="nav-link" href="#">Support</a>
                </nav>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\shitf_manager\resources\views/layout/inc/foot.blade.php ENDPATH**/ ?>