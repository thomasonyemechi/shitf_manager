<?php $__env->startSection('page_title'); ?>
    My Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <div class="pt-5 pb-5">
        <div class="container">

            <?php echo $__env->make('users.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row mt-0 mt-md-4">
                <div class="col-lg-3 col-md-4 col-12">

                    <?php echo $__env->make('users.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                <div class="col-lg-9 col-md-8 col-12">
					<!-- Card -->
					<div class="card">
						<!-- Card header -->
						<div class="card-header">
							<h3 class="mb-0">Bank and Pay details</h3>
							<p class="mb-0">
								You have full control to manage your own account setting.
							</p>
						</div>
						<!-- Card body -->
						<div class="card-body">
							
							<div>
								
								<!-- Form -->
								<form class="row">
									<!-- Account name -->
									<div class="mb-3 col-12 col-md-12">
										<label class="form-label" for="fname">Account Name</label>
										<input type="text" id="" class="form-control" placeholder="Account Name" required />
									</div>
									<!-- Acccount Number -->
									<div class="mb-3 col-12 col-md-12">
										<label class="form-label" for="lname">Account Number</label>
										<input type="text" id="" class="form-control" placeholder="Account Number" required />
									</div>
									<!-- bank name -->
									<div class="mb-3 col-12 col-md-12">
										<label class="form-label" for="lname">Bank Name</label>
										<input type="text" id="" class="form-control" placeholder="Bank Name" required />
									</div>
									<div class="col-12">
										<!-- Button -->
										<button class="btn btn-primary" type="submit">
											Update Account
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shitf_manager\resources\views/users/bankdetails.blade.php ENDPATH**/ ?>