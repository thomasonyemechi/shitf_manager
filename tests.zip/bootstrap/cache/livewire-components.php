<?php return array (
  'create-shift-index' => 'App\\Http\\Livewire\\CreateShiftIndex',
);